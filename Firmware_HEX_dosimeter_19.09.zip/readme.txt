*****************************************
DOSIMETER WITH PIC16F876A and LCD16x2
*****************************************
www.mygeiger.org
Author: Alex Boguslavsky
Email:  support@radiohobbystore.com
*****************************************
License: FREE FOR NON COMMERCIAL USE!
*****************************************
-----------------------------------------
Conversion Factor List:
-----------------------------------------
SBM-20 0.0057
SBM-19 0.0021
SI-29BG 0.0082
SI-180G 0.0031
LND-712 0.0081 or 0.0100
LND-7317 0.0024
J305 0.0081
SBT11-A 0.0031
SBT-9 0.0117
SBT-10 0.0013
-----------------------------------------

-----------------------------------------
YOUTUBE VIDEO:

http://youtu.be/qbvmdsixRL8

-----------------------------------------

Circuit and PCB layout:

http://vrtp.ru/index.php?act=categories&CODE=article&article=3422

-----------------------------------------
